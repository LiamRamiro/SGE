({
    myAction : function(component, event, helper) {

    },
    saludar : function(component, event, helper) {
        alert('Hola Mundo');
    }

})

function hola(component, event, helper) {
    //ecmascript 3

}
hola(component, event, helper)
saludar = function(component, event, helper) {
    alert('Hola Mundo');
}
saludar(component, event, helper)

